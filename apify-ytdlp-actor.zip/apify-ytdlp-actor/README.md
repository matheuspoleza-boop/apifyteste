# 🎬 YouTube Downloader Actor (yt-dlp)

Actor para Apify que baixa vídeos do YouTube usando o **yt-dlp** — a mesma engine open-source usada pelos maiores sites de download.

---

## 📁 Estrutura do projeto

```
apify-ytdlp-actor/
├── .actor/
│   ├── actor.json          # Configuração do actor
│   └── input_schema.json   # Schema do formulário de input
├── src/
│   └── main.py             # Lógica principal
├── Dockerfile              # Imagem Docker com Python + ffmpeg + yt-dlp
├── requirements.txt        # Dependências Python
└── README.md
```

---

## 🚀 Como criar no Apify (passo a passo)

### 1. Crie uma conta gratuita
Acesse https://apify.com e crie sua conta. O plano gratuito oferece **$5 de créditos/mês** — suficiente para muitos downloads.

### 2. Crie um novo Actor
- No painel, clique em **Actors → Create new**
- Escolha **"Start from scratch"**
- Dê o nome: `yt-dlp-downloader`

### 3. Faça upload dos arquivos
Na aba **Source**, selecione **"Git repository"** ou use o editor web:

**Opção A — Git (recomendado):**
1. Suba este projeto para um repositório GitHub público
2. Cole a URL do repo no campo Git repository
3. Clique em **Build**

**Opção B — Editor web (manual):**
1. Cole o conteúdo de cada arquivo diretamente no editor
2. Certifique-se de criar as pastas `.actor/` e `src/`
3. Clique em **Build**

### 4. Configure o Input
O actor aceita os seguintes campos:

| Campo | Tipo | Padrão | Descrição |
|-------|------|--------|-----------|
| `url` | string | — | URL do vídeo YouTube (obrigatório) |
| `format` | select | `mp4` | `mp4` ou `mp3` |
| `quality` | select | `720` | `best`, `1080`, `720`, `480`, `360` |
| `saveToKeyValueStore` | boolean | `false` | Salva o arquivo no KV Store (limite 9MB grátis) |
| `extractInfoOnly` | boolean | `false` | Só extrai metadados, sem baixar |

### 5. Execute
- Clique em **Start** e aguarde
- Os resultados aparecem no **Dataset** (metadados)
- Se `saveToKeyValueStore: true`, o arquivo fica disponível via URL do KV Store

---

## 💡 Modos de uso

### Modo 1 — Só metadados (grátis, rápido)
```json
{
  "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  "extractInfoOnly": true
}
```
Retorna título, duração, uploader, thumbnail, e **URLs diretas de todos os formatos disponíveis** — sem usar espaço em disco.

### Modo 2 — Download + salvar no KV Store
```json
{
  "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  "format": "mp3",
  "saveToKeyValueStore": true
}
```
Baixa como MP3 e disponibiliza via link do Apify.

### Modo 3 — Só registrar o download no Dataset
```json
{
  "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  "format": "mp4",
  "quality": "720"
}
```
Baixa o vídeo no container e salva os metadados no dataset (sem link, mas útil em pipelines).

---

## ⚠️ Limites do plano gratuito Apify

| Recurso | Limite grátis |
|---------|--------------|
| Créditos | $5/mês (~2h de CPU) |
| Memória | 128MB – 4GB por run |
| Key-Value Store | 9MB por record |
| Dataset | Ilimitado (só metadados) |

> Para vídeos grandes, use o modo `extractInfoOnly: true` para obter a URL direta e baixar pelo seu próprio navegador.

---

## 🛠️ Tecnologias

- **[yt-dlp](https://github.com/yt-dlp/yt-dlp)** — engine de download
- **ffmpeg** — merge de vídeo + áudio
- **Apify SDK (Python)** — integração com plataforma
- **Docker** — ambiente isolado e reproduzível
