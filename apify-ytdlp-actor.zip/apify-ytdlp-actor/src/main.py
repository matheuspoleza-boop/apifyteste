import asyncio
import json
import os
import subprocess
import glob

from apify import Actor


DOWNLOAD_DIR = "/tmp/yt-dlp-downloads"


def build_yt_dlp_command(url: str, fmt: str, quality: str, output_template: str) -> list[str]:
    """Build the yt-dlp CLI command based on user input."""
    cmd = ["yt-dlp", "--no-playlist", "-o", output_template]

    if fmt == "mp3":
        cmd += [
            "-x",
            "--audio-format", "mp3",
            "--audio-quality", "0",  # best quality
        ]
    else:
        # Map quality to yt-dlp format selector
        quality_map = {
            "best": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
            "1080": "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best",
            "720":  "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best",
            "480":  "bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/best[height<=480][ext=mp4]/best",
            "360":  "bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/best[height<=360][ext=mp4]/best",
        }
        fmt_selector = quality_map.get(quality, quality_map["720"])
        cmd += ["-f", fmt_selector, "--merge-output-format", "mp4"]

    cmd.append(url)
    return cmd


def extract_video_info(url: str) -> dict:
    """Use yt-dlp --dump-json to extract metadata without downloading."""
    result = subprocess.run(
        ["yt-dlp", "--dump-json", "--no-playlist", url],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"yt-dlp info extraction failed:\n{result.stderr}")

    return json.loads(result.stdout)


async def main() -> None:
    async with Actor:
        actor_input = await Actor.get_input() or {}

        url: str = actor_input.get("url", "").strip()
        fmt: str = actor_input.get("format", "mp4").lower()
        quality: str = str(actor_input.get("quality", "720"))
        save_to_kvs: bool = actor_input.get("saveToKeyValueStore", False)
        info_only: bool = actor_input.get("extractInfoOnly", False)

        if not url:
            Actor.log.error("❌ No URL provided. Please set the 'url' input field.")
            await Actor.set_status_message("Failed: no URL provided.")
            return

        Actor.log.info(f"🔗 Processing URL: {url}")

        # ── Step 1: Extract metadata ──────────────────────────────────────────
        Actor.log.info("📋 Extracting video metadata...")
        try:
            info = extract_video_info(url)
        except Exception as exc:
            Actor.log.error(f"❌ Failed to extract info: {exc}")
            await Actor.push_data({"url": url, "status": "error", "error": str(exc)})
            return

        title = info.get("title", "Unknown title")
        duration = info.get("duration")
        uploader = info.get("uploader")
        view_count = info.get("view_count")
        upload_date = info.get("upload_date")
        thumbnail = info.get("thumbnail")
        description = info.get("description", "")[:500]  # truncate

        # Collect available formats / direct stream URLs
        formats = [
            {
                "format_id": f.get("format_id"),
                "ext": f.get("ext"),
                "resolution": f.get("resolution") or f.get("format_note"),
                "filesize": f.get("filesize") or f.get("filesize_approx"),
                "url": f.get("url"),
            }
            for f in info.get("formats", [])
        ]

        Actor.log.info(f"✅ Found: '{title}' ({duration}s) — {len(formats)} formats available")

        # ── Step 2: Info-only mode ─────────────────────────────────────────────
        if info_only:
            await Actor.push_data({
                "status": "info_extracted",
                "url": url,
                "title": title,
                "uploader": uploader,
                "duration_seconds": duration,
                "upload_date": upload_date,
                "view_count": view_count,
                "thumbnail": thumbnail,
                "description": description,
                "formats": formats,
            })
            Actor.log.info("ℹ️  Info-only mode: skipping download.")
            return

        # ── Step 3: Download ───────────────────────────────────────────────────
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        output_template = os.path.join(DOWNLOAD_DIR, "%(title).100s.%(ext)s")

        cmd = build_yt_dlp_command(url, fmt, quality, output_template)
        Actor.log.info(f"⬇️  Downloading as {fmt.upper()} (quality: {quality})...")
        Actor.log.info(f"   Command: {' '.join(cmd)}")

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            error_msg = result.stderr[-2000:]  # last 2000 chars
            Actor.log.error(f"❌ yt-dlp download failed:\n{error_msg}")
            await Actor.push_data({
                "url": url,
                "title": title,
                "status": "download_error",
                "error": error_msg,
            })
            return

        # Find the downloaded file
        expected_ext = "mp3" if fmt == "mp3" else "mp4"
        files = glob.glob(os.path.join(DOWNLOAD_DIR, f"*.{expected_ext}"))
        if not files:
            # Fallback: any file in the dir
            files = glob.glob(os.path.join(DOWNLOAD_DIR, "*"))

        if not files:
            Actor.log.error("❌ Download appeared to succeed but no output file found.")
            await Actor.push_data({"url": url, "title": title, "status": "file_not_found"})
            return

        file_path = files[0]
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)

        Actor.log.info(f"✅ Downloaded: {file_name} ({file_size / 1024 / 1024:.1f} MB)")

        # ── Step 4: Optionally save to Key-Value Store ────────────────────────
        kvs_url = None
        if save_to_kvs:
            mime = "audio/mpeg" if expected_ext == "mp3" else "video/mp4"
            kvs_key = file_name.replace(" ", "_")
            Actor.log.info(f"📦 Uploading '{kvs_key}' to Key-Value Store...")
            kvs = await Actor.open_key_value_store()
            with open(file_path, "rb") as fh:
                await kvs.set_value(kvs_key, fh.read(), content_type=mime)
            kvs_url = f"https://api.apify.com/v2/key-value-stores/{kvs.id}/records/{kvs_key}"
            Actor.log.info(f"🔗 File available at: {kvs_url}")

        # ── Step 5: Push result to dataset ────────────────────────────────────
        await Actor.push_data({
            "status": "success",
            "url": url,
            "title": title,
            "uploader": uploader,
            "duration_seconds": duration,
            "upload_date": upload_date,
            "view_count": view_count,
            "thumbnail": thumbnail,
            "format": fmt,
            "quality": quality,
            "file_name": file_name,
            "file_size_bytes": file_size,
            "file_size_mb": round(file_size / 1024 / 1024, 2),
            "download_url": kvs_url,
        })

        Actor.log.info("🎉 Done! Check the dataset for results.")


asyncio.run(main())
